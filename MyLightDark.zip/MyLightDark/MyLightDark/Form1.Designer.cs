﻿namespace MyLightDark
{
    partial class Form1
    {
        /// <summary>
        /// Обов'язкова змінна конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Звільнення використаних ресурсів.
        /// </summary>
        /// <param name="disposing">true, якщо керований ресурс потрібно видалити; інакше false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Код, автоматично створений конструктором форм

        /// <summary>
        /// Метод для підтримки конструктора.
        /// Не змінюйте вміст цього методу в редакторі коду.
        /// </summary>
        private void InitializeComponent()
        {
            btnDark = new Button();
            btnLight = new Button();
            SuspendLayout();
            // 
            // btnDark
            // 
            btnDark.Location = new Point(477, 208);
            btnDark.Name = "btnDark";
            btnDark.Size = new Size(158, 38);
            btnDark.TabIndex = 0;
            btnDark.Text = "Темна тема";
            btnDark.UseVisualStyleBackColor = true;
            btnDark.Click += btnDark_Click;
            // 
            // btnLight
            // 
            btnLight.Location = new Point(477, 268);
            btnLight.Name = "btnLight";
            btnLight.Size = new Size(158, 38);
            btnLight.TabIndex = 1;
            btnLight.Text = "Світла тема";
            btnLight.UseVisualStyleBackColor = true;
            btnLight.Click += btnLight_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1136, 542);
            Controls.Add(btnLight);
            Controls.Add(btnDark);
            Name = "Form1";
            Text = "Налаштування теми";
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Button btnDark;
        private System.Windows.Forms.Button btnLight;
    }
}