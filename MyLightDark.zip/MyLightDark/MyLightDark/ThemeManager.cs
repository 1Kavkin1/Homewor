﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;

namespace MyLightDark
{
    public class ThemeSettings
    {
        public string theme { get; set; } = "light";
    }

    public static class ThemeManager
    {
        private static readonly string filePath = "appsettings.json";

        public static ThemeSettings LoadSettings()
        {
            if (!File.Exists(filePath))
            {
                var defaultSettings = new ThemeSettings { theme = "light" };
                SaveSettings(defaultSettings);
                return defaultSettings;
            }

            string json = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<ThemeSettings>(json) ?? new ThemeSettings();
        }

        public static void SaveSettings(ThemeSettings settings)
        {
            var options = new JsonSerializerOptions
            {
                WriteIndented = true
            };

            string json = JsonSerializer.Serialize(settings, options);
            File.WriteAllText(filePath, json);
        }
    }
}