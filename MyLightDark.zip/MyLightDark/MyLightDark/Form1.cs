using MyLightDark;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace MyLightDark
{
    public partial class Form1 : Form
    {
        private ThemeSettings currentSettings;

        public Form1()
        {
            InitializeComponent();

            currentSettings = ThemeManager.LoadSettings();
            ApplyTheme(currentSettings.theme);
        }

        private void ApplyTheme(string theme)
        {
            if (theme == "dark")
            {
                this.BackColor = Color.FromArgb(45, 45, 48);
                this.ForeColor = Color.White;

                foreach (Control control in this.Controls)
                {
                    control.BackColor = Color.FromArgb(45, 45, 48);
                    control.ForeColor = Color.White;
                }
            }
            else
            {
                this.BackColor = Color.White;
                this.ForeColor = Color.Black;

                foreach (Control control in this.Controls)
                {
                    control.BackColor = Color.White;
                    control.ForeColor = Color.Black;
                }
            }
        }

        private void btnDark_Click(object sender, EventArgs e)
        {
            currentSettings.theme = "dark";
            ThemeManager.SaveSettings(currentSettings);
            ApplyTheme(currentSettings.theme);
        }

        private void btnLight_Click(object sender, EventArgs e)
        {
            currentSettings.theme = "light";
            ThemeManager.SaveSettings(currentSettings);
            ApplyTheme(currentSettings.theme);
        }
    }
}